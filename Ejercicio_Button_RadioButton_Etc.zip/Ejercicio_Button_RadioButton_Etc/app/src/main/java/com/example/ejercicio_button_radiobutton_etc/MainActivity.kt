package com.example.ejercicio_button_radiobutton_etc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.sharp.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ejercicio_button_radiobutton_etc.ui.theme.Ejercicio_Button_RadioButton_EtcTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Ejercicio_Button_RadioButton_EtcTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaPricinipal()
                }
            }
        }
    }
}
/*
                        JOSÉ RAÚL SÁNCHEZ GARCÍA
 */

@Preview(showSystemUi = true)
@Composable
fun PantallaPricinipal() {
    //Declaración de variables
    var estaBotonPresionado by rememberSaveable {
        mutableStateOf(false)
    }
    var mensajeBoton by rememberSaveable {
        mutableStateOf("Botón presionado")
    }
    var estaActivado by rememberSaveable {
        mutableStateOf(false)
    }
    var mensajeCheck by rememberSaveable {
        mutableStateOf("Ahora me ves")
    }
    var estadoSwitch by rememberSaveable {
        mutableStateOf(false)
    }
    var radioSelected by rememberSaveable {
        mutableStateOf("Radio 1")
    }
    var mensajeRadio by rememberSaveable {
        mutableStateOf("")
    }
    var pasoImagen by rememberSaveable {
        mutableStateOf("")
    }

    //Solución
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //Apartado 1
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = Color.Black)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick =
                        {
                            estaBotonPresionado = !estaBotonPresionado
                        })
                    {
                        Text(
                            text = "Presionar"
                        )
                    }
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if(estaBotonPresionado){
                        Text(
                            text = "$mensajeBoton",
                            modifier = Modifier.fillMaxWidth(),
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 16.sp,
                                textAlign = TextAlign.End
                            )
                        )
                    }
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if (estaBotonPresionado) {
                        CircularProgressIndicator(color = Color.Red)
                    }
                }

            }
        }

        //Apartados 2 y 3
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Blue)
        ) {
            Row {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Checkbox(
                        checked = estaActivado,
                        onCheckedChange = { estaActivado = !estaActivado }
                    )
                    Text(
                        text = "Activar",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(25.dp, 0.dp, 0.dp, 0.dp),
                        style = TextStyle(
                            color = Color.Yellow,
                            fontSize = 18.sp
                        )
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if(estaActivado){
                        Text(
                            text = "$mensajeCheck",
                            style = TextStyle(
                                color = Color.Yellow,
                                fontSize = 18.sp
                            )
                        )
                    }
                }
            }
        }
        //Apartado 4
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Green)
        ) {
            Column {
                Row {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Sharp.Person,
                            contentDescription = "Icono",
                            tint = Color.Blue,
                        )
                    }

                }
            }
        }
        //Apartados 5 y 6
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.5f)
                .background(Color.Gray)
        ) {
            Row {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Switch(
                        checked = estadoSwitch,
                        onCheckedChange = { estadoSwitch = !estadoSwitch }
                        )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if(estadoSwitch){
                        Column(
                            Modifier.fillMaxSize()
                        ){
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = radioSelected == "Radio 1",
                                    onClick = {
                                        radioSelected = "Radio 1"
                                        mensajeRadio = "¡Buenos días!"
                                    }
                                )
                                Text(text = "Dia")
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = radioSelected == "Radio 2",
                                    onClick = {
                                        radioSelected = "Radio 2"
                                        mensajeRadio = "¡Buenas tardes!"
                                    }
                                )
                                Text(text = "Tarde")
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = radioSelected == "Radio 3",
                                    onClick = {
                                        radioSelected = "Radio 3"
                                        mensajeRadio = "¡Buenas noches!"
                                    }
                                )
                                Text(text = "Noche")
                            }
                            Text(text = "$mensajeRadio")
                        }
                    }
                }
            }
        }
        //Apartado 7
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Yellow)
            //,contentAlignment = Alignment.TopEnd
        ) {
            Row {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick =
                        {
                            when(pasoImagen){
                                "1" -> {
                                    pasoImagen = "2"
                                }
                                "2" -> {
                                    pasoImagen = "3"
                                }
                                "3" -> {
                                    pasoImagen = "1"
                                }
                                else -> {
                                    pasoImagen = "1"
                                }
                            }
                        })
                    {
                        Text(
                            text = "Cambiar Imagen"
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    when(pasoImagen){
                        "1" -> {
                            Image(
                                painter = painterResource(id = R.drawable.camaleon),
                                contentDescription = "Image"
                            )
                        }
                        "2" -> {
                            Image(
                                painter = painterResource(id = R.drawable.geronimo),
                                contentDescription = "Image"
                            )
                        }
                        "3" -> {
                            Image(
                                painter = painterResource(id = R.drawable.batpat),
                                contentDescription = "Image"
                            )
                        }
                    }
                }
            }
        }
    }
}
